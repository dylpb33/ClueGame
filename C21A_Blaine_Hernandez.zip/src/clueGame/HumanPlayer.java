package clueGame;

public class HumanPlayer extends Player{

	public HumanPlayer() {
		super();
	}

}
