// Authors: Jasmine Hernandez, Dylan Blaine

package clueGame;

public enum DoorDirection {
	
	UP, DOWN, LEFT, RIGHT, NONE

}
